const ThemeNumbers = () => {
  return (
    <section className="theme-number">
      <section id="color-theme1" className="theme-number">
        1
      </section>
      <section id="color-theme2" className="theme-number">
        2
      </section>
      <section id="color-theme3" className="theme-number">
        3
      </section>
    </section>
  );
};

export default ThemeNumbers;
